module.exports = function(data, connection, hook) { // eslint-disable-line no-unused-vars
  return data;
};
